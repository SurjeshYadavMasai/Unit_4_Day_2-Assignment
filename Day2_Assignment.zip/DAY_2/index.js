const express = require("express");
const app = express();


app.get("/home",  (req, res)=> {
  res.send("hello");
});

app.get("/books",  (req, res)=> {
  res.send([ book1 = { name: "A House of My Own: Stories from My Life",
                       writer: "Sandra Cisneros"
 },
             booke2 = {name: "A Little Book on Form",
                       writer: "Robert Hass"
            },
             booke3 = {name:  "A Personal Anthology",
                      writer: "Jorge Luis Borges"

            },
             booke4 = {name:  "A Room of One’s Own",
                       writer: "Virginia Woolf"
            },

]);
});


app.listen(4000, () => {
  console.log("listening on port 4000");
});
